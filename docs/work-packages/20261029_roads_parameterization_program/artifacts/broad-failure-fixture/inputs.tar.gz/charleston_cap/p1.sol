9002
# 
# WEPPcloud v.0.1.0 (c) University of Idaho
# 
# Build Date: 2026-09-11 00:23:06.144473
# Source Data: Surgo
# 
# Mukey: 53949
# Major Component: 26424166 (comppct_r = 100.0)
# Texture: loam
# 
# Chkey   hzname  mask hzdepb_r(cm) ksat_r(um/s) fraggt10_r frag3to10_r dbthirdbar_r    clay    sand     vfs      om
# ------------------------------------------------------------------------------------------------------------
# 78832314   A1             10.0     9.0        3.0        33.0         1.38    20.0    42.1    12.2     1.5
# 78832315   A2             28.0     9.0        3.0        33.0         1.22    20.0    26.5     8.8     1.5
# 78832316   Bt     R      152.0    0.91        3.0        33.0         1.22    30.0    35.8    10.7    1.25
# 
# Restricting Layer:
# ksat threshold (um/s): 2.00000
# type: N/A
# ksat (um/s): 0.91000
# 
# defaults applied to missing chorizon data:
# sandtotal_r  ->      66.800
# claytotal_r  ->       7.000
# om_r         ->       7.000
# cec7_r       ->      11.300
# sandvf_r     ->      10.000
# smr          ->      55.500
# 
# Build Notes:
# 78832314::wilt_pt estimated from wfifteenbar_r and rock
# 78832314::field_cap estimated from wthirdbar_r and rock
# 78832315::wilt_pt estimated from wfifteenbar_r and rock
# 78832315::field_cap estimated from wthirdbar_r and rock
# 78832316::wilt_pt estimated from wfifteenbar_r and rock
# 78832316::field_cap estimated from wthirdbar_r and rock
# res_lyr_i 2
# 
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# 
# 
# If you change the original contexts of this file please
# indicate it by putting an 'X' in the box here -> [ ]
# 
# 
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::9002migration
# Build Date: 2026-10-30 17:47:49.022246
# Source File: :/wc1/runs/ad/addicted-reservist/soils/53949.sol
# 
# Replacements
# --------------------------
# luse -> bare
# stext -> loam
# ki -> 1000000
# kr -> 6.00E-05
# shcrit -> 1
# avke -> 10
# bd ->
# ksflag -> 0
# ksatadj -> 1
# ksatfac -> 100
# ksatrec -> 0.3
# pmet_kcb -> 0.95
# pmet_rawp -> 0.8
# rdmax -> 0.2
# xmxlai -> 9
# keffflag -> 1
# lkeff -> 0.1
# plant.data.decfct -> 1
# plant.data.dropfc -> 1
# 
# h0_min_depth = None
# h0_max_om = None
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::modify_initial_sat(initial_sat=0.75)
Any comments:
3 0
0	 'bare'	 'loam'	 100 	 0.3
'Ess cobbly loam, 8 to 30 percent slopes'	 'CB-L'	 3	 0.16	 0.75	 2000000.0	 0.0003	 2
	100.0	 1.38	 8.1	 10.0	 0.37	 0.17	 42.1	 20.0	 1.5	 20.0	 50.4	 0.08605	 0.4087	 0.007631	 1.414	 18.71	 0.1314	 0.2495
	200.0	 1.22	 8.1	 10.0	 0.3636	 0.1534	 26.5	 20.0	 1.5	 20.0	 47.2	 0.08858	 0.4483	 0.004398	 1.484	 34.87	 0.1358	 0.2439
	400.0	 1.22	 32.4	 10.0	 0.3636	 0.1534	 26.5	 20.0	 1.5	 20.0	 47.2	 0.08858	 0.4483	 0.004398	 1.484	 34.87	 0.1358	 0.2439
1 10000.0 0.00328
1	 'bare'	 'loam'	 100 	 0.3
'Ess cobbly loam, 8 to 30 percent slopes'	 'CB-L'	 3	 0.16	 0.75	 1000000	 6e-05	 1
	100.0	 1.38	 10	 10.0	 0.37	 0.17	 42.1	 20.0	 1.5	 20.0	 50.4	 0.08605	 0.4087	 0.007631	 1.414	 18.71	 0.1314	 0.2495
	200.0	 1.22	 10	 10.0	 0.3636	 0.1534	 26.5	 20.0	 1.5	 20.0	 47.2	 0.08858	 0.4483	 0.004398	 1.484	 34.87	 0.1358	 0.2439
	400.0	 1.22	 32.4	 10.0	 0.3636	 0.1534	 26.5	 20.0	 1.5	 20.0	 47.2	 0.08858	 0.4483	 0.004398	 1.484	 34.87	 0.1358	 0.2439
1 10000.0 0.00328
0	 'forest'	 'loam'	 1.5 	 0.3
'Ess cobbly loam, 8 to 30 percent slopes'	 'CB-L'	 3	 0.16	 0.75	 400000	 3e-05	 1
	100.0	 1.38	 50	 10.0	 0.37	 0.17	 42.1	 20.0	 1.5	 20.0	 50.4	 0.08605	 0.4087	 0.007631	 1.414	 18.71	 0.1314	 0.2495
	200.0	 1.22	 50	 10.0	 0.3636	 0.1534	 26.5	 20.0	 1.5	 20.0	 47.2	 0.08858	 0.4483	 0.004398	 1.484	 34.87	 0.1358	 0.2439
	400.0	 1.22	 32.4	 10.0	 0.3636	 0.1534	 26.5	 20.0	 1.5	 20.0	 47.2	 0.08858	 0.4483	 0.004398	 1.484	 34.87	 0.1358	 0.2439
1 10000.0 0.00328
