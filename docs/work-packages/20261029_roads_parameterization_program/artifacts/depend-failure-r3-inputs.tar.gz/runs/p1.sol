9002
# 
# WEPPcloud v.0.1.0 (c) University of Idaho
# 
# Build Date: 2026-09-11 00:23:06.352036
# Source Data: Surgo
# 
# Mukey: 1718465
# Major Component: 26348995 (comppct_r = 90.0)
# Texture: sand loam
# 
# Chkey   hzname  mask hzdepb_r(cm) ksat_r(um/s) fraggt10_r frag3to10_r dbthirdbar_r    clay    sand     vfs      om
# ------------------------------------------------------------------------------------------------------------
# 78593707   Oi     X        2.0    28.0        0.0         0.0          0.9     1.0    94.0    10.0    70.0
# 78593704   A              15.0    28.0        0.0        35.0          1.4    12.5    67.9    10.7     2.5
# 78593705   Bt             28.0     2.7        0.0        55.0          1.4    31.0    35.4    10.6     2.5
# 78593706   R      R       38.0    0.42         -           -        1.5196     7.0    66.8    10.0     7.0
# 
# Restricting Layer:
# ksat threshold (um/s): 2.00000
# type: Lithic bedrock
# ksat (um/s): 0.42000
# 
# defaults applied to missing chorizon data:
# sandtotal_r  ->      66.800
# claytotal_r  ->       7.000
# om_r         ->       7.000
# cec7_r       ->      11.300
# sandvf_r     ->      10.000
# smr          ->      55.500
# 
# Build Notes:
# 78593704::wilt_pt estimated from wfifteenbar_r and rock
# 78593704::field_cap estimated from wthirdbar_r and rock
# 78593705::wilt_pt estimated from wfifteenbar_r and rock
# 78593705::field_cap estimated from wthirdbar_r and rock
# 78593706::using default rock content of 55.5%
# 78593706::wilt_pt estimated from rosetta2
# 78593706::field_cap estimated from rosetta2
# 78593706::bd estimated from sand, silt, and clay
# res_lyr_i 3
# 
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# 
# 
# If you change the original contexts of this file please
# indicate it by putting an 'X' in the box here -> [ ]
# 
# 
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::9002migration
# Build Date: 2026-10-30 17:47:25.345816
# Source File: :/wc1/runs/ad/addicted-reservist/soils/1718465.sol
# 
# Replacements
# --------------------------
# luse -> bare
# stext -> sand loam
# ki -> 400000
# kr -> 0.0001
# shcrit -> 2
# avke -> 10
# bd ->
# ksflag -> 0
# ksatadj -> 1
# ksatfac -> 100
# ksatrec -> 0.3
# pmet_kcb -> 0.95
# pmet_rawp -> 0.8
# rdmax -> 0.2
# xmxlai -> 9
# keffflag -> 1
# lkeff -> 0.1
# plant.data.decfct -> 1
# plant.data.dropfc -> 1
# 
# h0_min_depth = None
# h0_max_om = None
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::modify_initial_sat(initial_sat=0.75)
Any comments:
3 0
0	 'bare'	 'sand loam'	 100 	 0.3
'Bushvalley cobbly sandy loam, 5 to 40 percent slopes'	 'CB-SL'	 3	 0.16	 0.75	 500000	 0.0001	 2
	150.0	 1.4	 10	 10.0	 0.2615	 0.1385	 67.9	 12.5	 2.5	 15.0	 48.0	 0.07107	 0.4041	 0.01539	 1.489	 56.47	 0.09439	 0.2071
	200.0	 1.4	 10	 10.0	 0.314	 0.198	 35.4	 31.0	 2.5	 15.0	 68.5	 0.1042	 0.4261	 0.007803	 1.352	 12.09	 0.1644	 0.2884
	400.0	 1.4	 9.72	 10.0	 0.314	 0.198	 35.4	 31.0	 2.5	 15.0	 68.5	 0.1042	 0.4261	 0.007803	 1.352	 12.09	 0.1644	 0.2884
1 10000.0 0.00151
0	 'bare'	 'sand loam'	 100 	 0.3
'Bushvalley cobbly sandy loam, 5 to 40 percent slopes'	 'CB-SL'	 3	 0.16	 0.75	 400000	 0.0001	 2
	150.0	 1.4	 10	 10.0	 0.2615	 0.1385	 67.9	 12.5	 2.5	 15.0	 48.0	 0.07107	 0.4041	 0.01539	 1.489	 56.47	 0.09439	 0.2071
	200.0	 1.4	 10	 10.0	 0.314	 0.198	 35.4	 31.0	 2.5	 15.0	 68.5	 0.1042	 0.4261	 0.007803	 1.352	 12.09	 0.1644	 0.2884
	400.0	 1.4	 9.72	 10.0	 0.314	 0.198	 35.4	 31.0	 2.5	 15.0	 68.5	 0.1042	 0.4261	 0.007803	 1.352	 12.09	 0.1644	 0.2884
1 10000.0 0.00151
0	 'forest'	 'sand loam'	 1.5 	 0.3
'Bushvalley cobbly sandy loam, 5 to 40 percent slopes'	 'CB-SL'	 3	 0.16	 0.75	 400000	 8e-05	 2
	150.0	 1.4	 60	 10.0	 0.2615	 0.1385	 67.9	 12.5	 2.5	 15.0	 48.0	 0.07107	 0.4041	 0.01539	 1.489	 56.47	 0.09439	 0.2071
	200.0	 1.4	 60	 10.0	 0.314	 0.198	 35.4	 31.0	 2.5	 15.0	 68.5	 0.1042	 0.4261	 0.007803	 1.352	 12.09	 0.1644	 0.2884
	400.0	 1.4	 9.72	 10.0	 0.314	 0.198	 35.4	 31.0	 2.5	 15.0	 68.5	 0.1042	 0.4261	 0.007803	 1.352	 12.09	 0.1644	 0.2884
1 10000.0 0.00151
