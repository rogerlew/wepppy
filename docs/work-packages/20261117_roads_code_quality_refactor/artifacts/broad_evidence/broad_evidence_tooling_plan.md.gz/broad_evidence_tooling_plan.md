# External evidence tooling (prepared while v5 runs)

No source files are modified by this tooling. Preparation, packaging and complete
execution do not imply accepted validation. Keep failed attempts and unresolved
failure attribution visible.

## Exact composite reconciliation

Use the immutable full ordered collection of 15,104 unique node IDs. Require
every referenced inventory to match it exactly. Populate a per-node evidence map
from these disjoint selections, in collection order:

1. Full indices `[0:3484]` minus the 537 canonical-prefix nodes: 2,947 items.
   Outcomes come from corresponding positions in the original v3 progress string,
   with the documented retrospective-order limitation: 2,822 pass, 125 skip.
2. The exact 537 canonical-prefix nodes, complete phases and 17 source hashes:
   508 pass, 29 skip. Replace all their original-prefix outcomes.
3. Full indices `[3484:6005]`, from completed v2 phase reports: 2,518 pass, 3 skip.
   Require the independently verified post-exit source equivalence.
4. Full indices `[6005:8251]`, from completed v3 phase reports: 2,170 pass, 76 skip.
   Require v3 source/environment equivalence and intact observer evidence.
5. Full indices `[8251:15104]`, from the complete v5 diagnostic: 6,853 items.
   Keep every pass, skip, expected failure, unexpected pass and failure explicit.
   Require all phases, unchanged source/environment, intact pinned evidence and
   the actual process exit. v4 partial outcomes never enter this map.

Before replacements, the first 8,251 nodes account for 8,018 passes and 233
runtime skips. All v5 failure nodes remain failures regardless of baseline
attribution; baseline evidence explains scope but does not make them pass.

For a reviewed replacement, identify every node belonging to each complete
selected module in the full inventory. Require the module to lie entirely in the
v5 suffix, the replacement's selected IDs to equal those nodes in order, complete
phases and final source fingerprints, and explicit exact old/new source hashes.
Only module-local test changes are permitted by the prepared replacement runner.
Reject shared conftest/config/production changes pending wider validation.
Remove all previous module outcomes before adding that selected replacement run;
never add duplicate passes or select only the formerly failing cases. Choose the
accepted replacement explicitly, rather than automatically choosing a newest file.

Final keys must equal the full ordered inventory without duplicate or missing
nodes. Keep collection skips separate from runtime skips, and retain subtest and
xfail metadata separately. Missing phases, failures, integrity drift or unknown
source transitions prevent a green composite conclusion. Cross-module effects
or cascading failures may require wider reruns. Preserve the original mixed
environment and each process-boundary limitation in every final verdict.

## Complete-module replacement runner

`run_broad_module_replacements.py` accepts one explicit JSON specification. No
modules are selected until diagnostic classification and source review finish.
The adjacent `broad_replacement_spec.template.json` deliberately cannot execute
until its required values and module selection are filled.

Invoke through the existing canonical guarded helper, using a fresh label:

```text
python3 /tmp/roads_environment_command.py LABEL /opt/venv/bin/python /tmp/roads-refactor-validation/run_broad_module_replacements.py /tmp/roads-refactor-validation/REVIEWED_SPEC.json
```

The runner uses the reviewed v5 source-manifest function with its source hash
pinned, collects the entire suite before selecting whole modules, records exact
node IDs and buffered phase reports, and writes before/after source/environment
fingerprints. Each evidence label and basetemp must be new. It uses maxfail=0 and
does not erase failures. `coverage_complete` and `eligible_for_review` are separate
from acceptance; no automatic composite acceptance is produced.

## Exact-byte packaging

`package_broad_evidence.py` accepts an explicit list of existing absolute files
and a new output directory. It writes deterministic gzip files (mtime zero, no
embedded filename), verifies decompressed bytes, rechecks every original and
records original/compressed hashes and byte counts. It preserves trailing
whitespace and newlines exactly. The receipt has no acceptance claim. An
interrupted or failed package remains marked incomplete and must not be relabeled.

```text
/usr/bin/python /tmp/roads-refactor-validation/package_broad_evidence.py --spec /tmp/roads-refactor-validation/REVIEWED_PACKAGE_SPEC.json --destination NEW_DIRECTORY
```

The prepared package specification includes required v5 closing files so it fails
before creating output while the diagnostic is incomplete. Add final replacement
specifications, inventories, reports, manifests, logs, source-review receipts and
the final reconciliation before making the final package. Preserve original
runtime evidence even after packaging.

Preparation checks passed: deterministic gzip roundtrip preserves exact test
bytes including trailing whitespace; the phase classifier distinguishes pass,
skip, failure, xfail and missing teardown. No replacement pytest execution or
final evidence packaging has been performed during the running diagnostic.

## Reviewed runtime inputs

Unchanged source is supported with an empty approved-source-change map. A reviewed
runtime-only replacement must still state its environment variance explicitly.
The optional `runtime_environment` map asserts selected variable values (including
null for unset); canonical retention values cannot be overridden. Optional
`runtime_files` entries specify exact absolute paths, hashes and whether each must
be its own read-only mount. Before/after receipts retain content hashes, sizes,
timestamps, modes, executable status and mount identity. Such entries require an
explicit `runtime_delta_review`; no files are built, installed or mounted by the
runner itself.

For the approved existing shape parser, the guarded shape helper supplies only
the binary and sidecar as read-only mounts at `/usr/local/bin/shape_parser_cli` and
`/usr/local/bin/shape_parser_cli.json`. Record both hashes and the unset parser
override/scratch variables in the reviewed specification. Retain the independent
sidecar/source identity and baseline/candidate missing-artifact evidence. Module
selection and execution wait for v5 completion; do not silently portray this
replacement environment as identical to the original diagnostic.
