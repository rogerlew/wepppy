9002
# 
# WEPPcloud (c) University of Idaho
# 
# Build Date: 2026-11-06 18:09:36.599361
# Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
# 
# 
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# 
# Source warning: source.categorical.empty field=fao90lev1
# ESDAC ESDB Soil Parameters
# 
# Attribute           PX    Abbr  Long Desc.
# ------------------------------------------------------------------------------------------------------------------------
# fao90lev1           24    unknownNo information
# usedom              5     5     Forest, coppice
# textdepchg          5     5     No textural change between 20 and 120 cm depth
# il                  1     1     No impermeable layer within 150 cm
# cectop              2     L     Low ( < 15 cmol(+)/kg)
# cecsub              2     L     Low ( < 15 cmol(+)/kg)
# dgh                 2     V     Very deep ( > 120 cm)
# dimp                1     D     Deep ( > 80 cm)
# dr                  1     D     Deep (80 - 120 cm)
# 
# ESDAC STU Soil Parameters
# 
# Attribute        Top       Sub
# ------------------------------------------------------------------------------------------------------------------------
# CLAY             5.0       4.0
# SAND            85.0      86.0
# SILT            10.0      10.0
# OC               2.0       0.5
# BD               1.7       1.7
# GRAVEL           3.0       3.0
# 
# Rosetta Soil Parameter Estimates Based on ESDAC
# 
# Attribute        Top       Sub
# ------------------------------------------------------------------------------------------------------------------------
# theta_r          0.1       0.1
# theta_s          0.3       0.3
# alpha            0.0       0.0
# npar             1.9       1.9
# ks             101.9     108.8
# wp               0.1       0.1
# fc               0.1       0.1
# + ks, wp, and fc used for WEPP soil parameters
# 
# Land IS Forest
# salb = 0.06
# ini_sat = 0.5
# 
# EU Soil Hydro Grids
# 
# Code	Depth	ksat
# ------------------------------------------------------------------------------------------------------------------------
# sl1  	0  	11.533334256
# sl2  	5  	11.533334256
# sl3  	15  	11.533334256
# sl4  	30  	11.533334256
# sl5  	60  	0.233333352
# sl6  	100  	0.233333352
# sl7  	200  	0.233333352
# 
# res_lyr_ksat_threshold = 2.0
# res_lyr_i = 6
# ksat_last = 0.233333352
# 
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::9002migration
#   Build Date: 2026-11-06 18:10:01.579321
#   Source File: :/tmp/esdac-incident-20261106-final/unknown_5_5_1_L_L_V_D_D_5,10,85,2.sol
# 
#   Replacements
#   --------------------------
#   luse -> forest low sev fire
#   stext -> sand loam
#   ki -> 400000
#   kr -> 0.00012
#   shcrit -> 2
#   avke -> 20
#   bd -> 
#   ksflag -> 0
#   ksatadj -> 0
#   ksatfac -> 1.3
#   ksatrec -> 0.3
#   pmet_kcb -> 0.95
#   pmet_rawp -> 0.8
#   rdmax -> 0.3
#   xmxlai -> 4
#   keffflag -> 1
#   lkeff -> 10
#   plant.data.decfct -> 1
#   plant.data.dropfc -> 1
# 
#   h0_min_depth = None
#   h0_max_om = None
# 
Any comments:
1 0
0	 'forest low sev fire'	 'sand loam'	 1.3 	 0.3
'No information'	 'sand loam'	 3	 0.06	 0.5	 400000	 0.00012	 2
	200.0	 1.7	 20	 1.0	 0.1138	 0.0538	 85.0	 5.0	 2.02	 10.0	 3.0	 0.0523	 0.3278	 0.02807	 1.865	 101.9	 0.05378	 0.1138
	1200.0	 1.7	 101.8654	 1.0	 0.1138	 0.0538	 85.0	 5.0	 2.02	 10.0	 3.0	 0.0523	 0.3278	 0.02807	 1.865	 101.9	 0.05378	 0.1138
	1500.0	 1.73	 108.7842	 1.0	 0.1055	 0.0513	 86.0	 4.0	 0.51	 10.0	 3.0	 0.05035	 0.3193	 0.02943	 1.924	 108.8	 0.05132	 0.1055
1 10000.0 0.84
