9002
# 
# WEPPcloud (c) University of Idaho
# 
# Build Date: 2026-11-06 18:09:38.550656
# Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
# 
# 
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# 
# Source warning: source.categorical.empty field=fao90lev1
# ESDAC ESDB Soil Parameters
# 
# Attribute           PX    Abbr  Long Desc.
# ------------------------------------------------------------------------------------------------------------------------
# fao90lev1           24    unknownNo information
# usedom              5     5     Forest, coppice
# textdepchg          5     5     No textural change between 20 and 120 cm depth
# il                  1     1     No impermeable layer within 150 cm
# cectop              2     L     Low ( < 15 cmol(+)/kg)
# cecsub              2     L     Low ( < 15 cmol(+)/kg)
# dgh                 2     V     Very deep ( > 120 cm)
# dimp                1     D     Deep ( > 80 cm)
# dr                  1     D     Deep (80 - 120 cm)
# 
# ESDAC STU Soil Parameters
# 
# Attribute        Top       Sub
# ------------------------------------------------------------------------------------------------------------------------
# CLAY            20.0      20.0
# SAND            42.0      45.0
# SILT            38.0      35.0
# OC               1.5       0.5
# BD               1.4       1.4
# GRAVEL          10.0      19.0
# 
# Rosetta Soil Parameter Estimates Based on ESDAC
# 
# Attribute        Top       Sub
# ------------------------------------------------------------------------------------------------------------------------
# theta_r          0.1       0.1
# theta_s          0.4       0.4
# alpha            0.0       0.0
# npar             1.4       1.4
# ks              16.5      16.9
# wp               0.1       0.1
# fc               0.2       0.2
# + ks, wp, and fc used for WEPP soil parameters
# 
# Land IS Forest
# salb = 0.06
# ini_sat = 0.5
# 
# EU Soil Hydro Grids
# 
# Code	Depth	ksat
# ------------------------------------------------------------------------------------------------------------------------
# sl1  	0  	11.533334256
# sl2  	5  	11.533334256
# sl3  	15  	11.533334256
# sl4  	30  	11.533334256
# sl5  	60  	0.233333352
# sl6  	100  	0.233333352
# sl7  	200  	0.233333352
# 
# res_lyr_ksat_threshold = 2.0
# res_lyr_i = 6
# ksat_last = 0.233333352
# 
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::9002migration
#   Build Date: 2026-11-06 18:09:53.370967
#   Source File: :/tmp/esdac-incident-20261106-final/unknown_5_5_1_L_L_V_D_D_20,38,42,1.sol
# 
#   Replacements
#   --------------------------
#   luse -> forest low sev fire
#   stext -> loam
#   ki -> 1000000
#   kr -> 8.00E-05
#   shcrit -> 1
#   avke -> 20
#   bd -> 
#   ksflag -> 0
#   ksatadj -> 0
#   ksatfac -> 1.3
#   ksatrec -> 0.3
#   pmet_kcb -> 0.95
#   pmet_rawp -> 0.8
#   rdmax -> 0.3
#   xmxlai -> 4
#   keffflag -> 1
#   lkeff -> 10
#   plant.data.decfct -> 1
#   plant.data.dropfc -> 1
# 
#   h0_min_depth = None
#   h0_max_om = None
# 
Any comments:
1 0
0	 'forest low sev fire'	 'loam'	 1.3 	 0.3
'No information'	 'loam'	 3	 0.06	 0.5	 1000000	 8.00E-05	 1
	200.0	 1.41	 20	 1.0	 0.2488	 0.1308	 42.0	 20.0	 1.45	 10.0	 10.0	 0.08557	 0.4018	 0.007774	 1.409	 16.46	 0.1308	 0.2488
	1200.0	 1.41	 16.4627	 1.0	 0.2488	 0.1308	 42.0	 20.0	 1.45	 10.0	 10.0	 0.08557	 0.4018	 0.007774	 1.409	 16.46	 0.1308	 0.2488
	1500.0	 1.42	 16.9413	 1.0	 0.2494	 0.1303	 45.0	 20.0	 0.5	 10.0	 19.0	 0.08533	 0.4007	 0.008541	 1.401	 16.94	 0.1303	 0.2494
1 10000.0 0.84
