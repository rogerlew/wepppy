7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:08:59.583433
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           16    CH    Chernozem
#  usedom              3     3     Arable land, cereals
#  textdepchg          5     5     No textural change between 20 and 120 cm depth
#  il                  1     1     No impermeable layer within 150 cm
#  cectop              2     L     Low ( < 15 cmol(+)/kg)
#  cecsub              2     L     Low ( < 15 cmol(+)/kg)
#  dgh                 2     V     Very deep ( > 120 cm)
#  dimp                1     D     Deep ( > 80 cm)
#  dr                  1     D     Deep (80 - 120 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            25.0      25.0
#  SAND            28.0      28.0
#  SILT            47.0      47.0
#  OC               1.6       0.8
#  BD               1.4       1.4
#  GRAVEL           4.0      17.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.4       0.4
#  alpha            0.0       0.0
#  npar             1.4       1.4
#  ks              15.5      15.5
#  wp               0.1       0.1
#  fc               0.3       0.3
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	0.254166687
#  sl2  	5  	27.300002184
#  sl3  	15  	27.595835541
#  sl4  	30  	27.595835541
#  sl5  	60  	14.200001136
#  sl6  	100  	14.200001136
#  sl7  	200  	14.200001136
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 0
#  ksat_last = 14.200001136
#
Any comments:
1 0
'Chernozem'		'loam'	3	0.1500	0.7500	4675750.00	0.0078	3.5000
	 200.0	    1.35	  15.4879	  1.0	   0.2649	   0.1476	  28.00	  25.00	   1.65	  10.00	   4.00
	 1200.000	    1.35	  15.4879	  1.0	   0.2649	   0.1476	  28.00	  25.00	   1.65	  10.00	   4.00
	 1500.000	    1.35	  15.4879	  1.0	   0.2649	   0.1476	  28.00	  25.00	   0.78	  10.00	  17.00
1 10000.0 0.91500