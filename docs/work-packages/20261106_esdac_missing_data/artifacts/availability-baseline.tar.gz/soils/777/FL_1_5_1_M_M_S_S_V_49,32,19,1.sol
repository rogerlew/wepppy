7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:08:57.243314
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           9     FL    Fluvisol
#  usedom              1     1     Pasture, grassland, grazing land
#  textdepchg          5     5     No textural change between 20 and 120 cm depth
#  il                  1     1     No impermeable layer within 150 cm
#  cectop              1     M     Medium (15-40 cmol(+)/kg)
#  cecsub              1     M     Medium (15-40 cmol(+)/kg)
#  dgh                 3     S     Shallow ( < 40 cm)
#  dimp                2     S     Shallow ( < 80 cm)
#  dr                  5     V     Very deep ( > 120 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            49.0      47.0
#  SAND            19.0      21.0
#  SILT            32.0      32.0
#  OC               1.2       0.6
#  BD               1.2       1.2
#  GRAVEL           4.0       3.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.5       0.5
#  alpha            0.0       0.0
#  npar             1.3       1.3
#  ks              22.9      23.2
#  wp               0.2       0.2
#  fc               0.3       0.3
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	0.254166687
#  sl2  	5  	0.254166687
#  sl3  	15  	22.037501762999998
#  sl4  	30  	27.595835541
#  sl5  	60  	14.200001136
#  sl6  	100  	0.008333334
#  sl7  	200  	0.008333334
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 6
#  ksat_last = 0.008333334
#
Any comments:
1 0
'Fluvisol'		'clay loam'	3	0.1500	0.7500	3352630.00	0.0069	3.5000
	 200.0	    1.24	  22.8935	  1.0	   0.3473	   0.2131	  19.00	  49.00	   1.19	  27.50	   4.00
	 1200.000	    1.24	  22.8935	  1.0	   0.3473	   0.2131	  19.00	  49.00	   1.19	  27.50	   4.00
	 1500.000	    1.24	  23.2212	  1.0	   0.3419	   0.2084	  21.00	  47.00	   0.55	  27.50	   3.00
1 10000.0 0.03000