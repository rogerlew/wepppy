7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:09:49.526492
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           33    AC    Acrisol
#  usedom              3     3     Arable land, cereals
#  textdepchg          1     1     Textural change between 20 and 40 cm depth
#  il                  4     4     Impermeable layer within 40 cm
#  cectop              2     L     Low ( < 15 cmol(+)/kg)
#  cecsub              1     M     Medium (15-40 cmol(+)/kg)
#  dgh                 1     M     Moderate (40 - 80 cm)
#  dimp                2     S     Shallow ( < 80 cm)
#  dr                  5     V     Very deep ( > 120 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY             9.0      22.0
#  SAND            80.0      68.0
#  SILT            11.0      10.0
#  OC               0.6       0.3
#  BD               1.6       1.5
#  GRAVEL           4.0       5.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.4       0.4
#  alpha            0.0       0.0
#  npar             1.7       1.4
#  ks              72.4      36.5
#  wp               0.1       0.1
#  fc               0.2       0.2
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	27.300002184
#  sl2  	5  	27.595835541
#  sl3  	15  	27.595835541
#  sl4  	30  	14.200001136
#  sl5  	60  	0.162500013
#  sl6  	100  	7.975000637999999
#  sl7  	200  	7.975000637999999
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 4
#  ksat_last = 7.975000637999999
#
Any comments:
1 0
'Acrisol'		'sand loam'	3	0.1500	0.7500	4841100.00	0.0174	2.6170
	  200.0	    1.60	  72.4224	  1.0	   0.1523	   0.0668	  80.00	   9.00	   0.63	  10.00	   4.00
	  300.000	    1.60	  72.4224	  1.0	   0.1523	   0.0668	  80.00	   9.00	   0.63	  10.00	   4.00
	  400.000	    1.45	  36.5304	  1.0	   0.2455	   0.1231	  68.00	  22.00	   0.30	  27.50	   5.00
1 10000.0 0.58500