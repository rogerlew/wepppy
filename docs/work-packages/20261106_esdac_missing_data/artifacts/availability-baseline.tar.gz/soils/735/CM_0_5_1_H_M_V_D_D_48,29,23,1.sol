7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:08:42.791837
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           11    CM    Cambisol
#  usedom              0     0     No information
#  textdepchg          5     5     No textural change between 20 and 120 cm depth
#  il                  1     1     No impermeable layer within 150 cm
#  cectop              3     H     High ( > 40 cmol(+)/kg)
#  cecsub              1     M     Medium (15-40 cmol(+)/kg)
#  dgh                 2     V     Very deep ( > 120 cm)
#  dimp                1     D     Deep ( > 80 cm)
#  dr                  1     D     Deep (80 - 120 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            48.0      45.0
#  SAND            23.0      26.0
#  SILT            29.0      29.0
#  OC               1.2       0.6
#  BD               1.2       1.2
#  GRAVEL          10.0      24.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.5       0.5
#  alpha            0.0       0.0
#  npar             1.3       1.3
#  ks              22.8      23.4
#  wp               0.2       0.2
#  fc               0.3       0.3
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	0.254166687
#  sl2  	5  	0.254166687
#  sl3  	15  	0.254166687
#  sl4  	30  	27.595835541
#  sl5  	60  	14.200001136
#  sl6  	100  	14.200001136
#  sl7  	200  	14.200001136
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 2
#  ksat_last = 14.200001136
#
Any comments:
1 0
'Cambisol'		'clay loam'	3	0.1500	0.7500	3407760.00	0.0069	3.5000
	 200.0	    1.25	  22.8380	  1.0	   0.3449	   0.2106	  23.00	  48.00	   1.17	  50.00	  10.00
	 1200.000	    1.25	  22.8380	  1.0	   0.3449	   0.2106	  23.00	  48.00	   1.17	  50.00	  10.00
	 1500.000	    1.25	  23.3555	  1.0	   0.3370	   0.2036	  26.00	  45.00	   0.58	  27.50	  24.00
1 10000.0 0.91500