7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:09:25.278844
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           26    LV    Luvisol
#  usedom              5     5     Forest, coppice
#  textdepchg          1     1     Textural change between 20 and 40 cm depth
#  il                  1     1     No impermeable layer within 150 cm
#  cectop              2     L     Low ( < 15 cmol(+)/kg)
#  cecsub              1     M     Medium (15-40 cmol(+)/kg)
#  dgh                 2     V     Very deep ( > 120 cm)
#  dimp                2     S     Shallow ( < 80 cm)
#  dr                  5     V     Very deep ( > 120 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            22.0      29.0
#  SAND            41.0      37.0
#  SILT            37.0      34.0
#  OC               0.7       0.4
#  BD               1.4       1.4
#  GRAVEL           4.0       3.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.4       0.4
#  alpha            0.0       0.0
#  npar             1.4       1.4
#  ks              15.7      16.0
#  wp               0.1       0.2
#  fc               0.3       0.3
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS Forest
#    salb = 0.06
#    ini_sat = 0.5
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	0.254166687
#  sl2  	5  	0.254166687
#  sl3  	15  	22.037501762999998
#  sl4  	30  	27.595835541
#  sl5  	60  	14.200001136
#  sl6  	100  	14.200001136
#  sl7  	200  	14.200001136
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 1
#  ksat_last = 14.200001136
#
Any comments:
1 0
'Luvisol'		'loam'	3	0.0600	0.5000	9835700.00	0.0230	1.9540
	  200.0	    1.40	  15.6896	  1.0	   0.2569	   0.1375	  41.00	  22.00	   0.74	  10.00	   4.00
	  300.000	    1.40	  15.6896	  1.0	   0.2569	   0.1375	  41.00	  22.00	   0.74	  10.00	   4.00
	 1500.000	    1.35	  16.0228	  1.0	   0.2838	   0.1596	  37.00	  29.00	   0.36	  27.50	   3.00
1 10000.0 0.91500