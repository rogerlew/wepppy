7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:09:44.093557
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           26    LV    Luvisol
#  usedom              3     3     Arable land, cereals
#  textdepchg          3     3     Textural change between 60 and 80 cm depth
#  il                  1     1     No impermeable layer within 150 cm
#  cectop              1     M     Medium (15-40 cmol(+)/kg)
#  cecsub              4     H     High ( > 40 cmol(+)/kg)
#  dgh                 2     V     Very deep ( > 120 cm)
#  dimp                2     S     Shallow ( < 80 cm)
#  dr                  1     D     Deep (80 - 120 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            46.0      54.0
#  SAND            27.0      21.0
#  SILT            27.0      25.0
#  OC               1.2       0.6
#  BD               1.3       1.2
#  GRAVEL           4.0       6.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.5       0.5
#  alpha            0.0       0.0
#  npar             1.3       1.3
#  ks              22.8      26.5
#  wp               0.2       0.2
#  fc               0.3       0.4
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	0.254166687
#  sl2  	5  	0.254166687
#  sl3  	15  	0.254166687
#  sl4  	30  	0.254166687
#  sl5  	60  	8.850000708
#  sl6  	100  	5.662500453
#  sl7  	200  	5.662500453
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 3
#  ksat_last = 5.662500453
#
Any comments:
1 0
'Luvisol'		'clay loam'	3	0.1500	0.7500	3518020.00	0.0069	3.5000
	  200.0	    1.26	  22.7920	  1.0	   0.3397	   0.2059	  27.00	  46.00	   1.20	  27.50	   4.00
	  700.000	    1.26	  22.7920	  1.0	   0.3397	   0.2059	  27.00	  46.00	   1.20	  27.50	   4.00
	 1500.000	    1.22	  26.4909	  1.0	   0.3631	   0.2258	  21.00	  54.00	   0.58	  50.00	   6.00
1 10000.0 0.91500