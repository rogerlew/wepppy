7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:09:08.321864
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           15    RG    Regosol
#  usedom              5     5     Forest, coppice
#  textdepchg          5     5     No textural change between 20 and 120 cm depth
#  il                  1     1     No impermeable layer within 150 cm
#  cectop              1     M     Medium (15-40 cmol(+)/kg)
#  cecsub              2     L     Low ( < 15 cmol(+)/kg)
#  dgh                 2     V     Very deep ( > 120 cm)
#  dimp                1     D     Deep ( > 80 cm)
#  dr                  4     S     Shallow ( < 40 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            23.0      24.0
#  SAND            41.0      44.0
#  SILT            36.0      32.0
#  OC               2.7       1.1
#  BD               1.4       1.4
#  GRAVEL           8.0       6.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.4       0.4
#  alpha            0.0       0.0
#  npar             1.4       1.4
#  ks              15.9      16.8
#  wp               0.1       0.1
#  fc               0.3       0.3
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS Forest
#    salb = 0.06
#    ini_sat = 0.5
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	11.533334256
#  sl2  	5  	11.533334256
#  sl3  	15  	27.300002184
#  sl4  	30  	27.595835541
#  sl5  	60  	14.200001136
#  sl6  	100  	14.200001136
#  sl7  	200  	14.200001136
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = None
#  ksat_last = 14.200001136
#
Any comments:
1 0
'Regosol'		'loam'	3	0.0600	0.5000	9643600.00	0.0130	2.0770
	 200.0	    1.39	  15.9280	  1.0	   0.2612	   0.1408	  41.00	  23.00	   2.72	  27.50	   8.00
	 1200.000	    1.39	  15.9280	  1.0	   0.2612	   0.1408	  41.00	  23.00	   2.72	  27.50	   8.00
	 1500.000	    1.39	  16.8050	  1.0	   0.2659	   0.1437	  44.00	  24.00	   1.07	  10.00	   6.00
1 10000.0 14.20000