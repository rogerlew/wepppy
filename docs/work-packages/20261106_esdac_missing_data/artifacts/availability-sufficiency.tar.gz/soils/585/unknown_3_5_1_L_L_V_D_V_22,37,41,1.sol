7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:19:02.923737
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# Source warning: source.categorical.empty field=fao90lev1
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           24    unknownNo information
#  usedom              3     3     Arable land, cereals
#  textdepchg          5     5     No textural change between 20 and 120 cm depth
#  il                  1     1     No impermeable layer within 150 cm
#  cectop              2     L     Low ( < 15 cmol(+)/kg)
#  cecsub              2     L     Low ( < 15 cmol(+)/kg)
#  dgh                 2     V     Very deep ( > 120 cm)
#  dimp                1     D     Deep ( > 80 cm)
#  dr                  5     V     Very deep ( > 120 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            22.0      29.0
#  SAND            41.0      37.0
#  SILT            37.0      34.0
#  OC               0.7       0.4
#  BD               1.4       1.4
#  GRAVEL           4.0       3.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.4       0.4
#  alpha            0.0       0.0
#  npar             1.4       1.4
#  ks              15.7      16.0
#  wp               0.1       0.2
#  fc               0.3       0.3
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	11.533334256
#  sl2  	5  	11.533334256
#  sl3  	15  	11.533334256
#  sl4  	30  	11.533334256
#  sl5  	60  	8.850000708
#  sl6  	100  	8.850000708
#  sl7  	200  	8.850000708
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = None
#  ksat_last = 8.850000708
#
Any comments:
1 0
'No information'		'loam'	3	0.1500	0.7500	9835700.00	0.0230	1.9540
	 200.0	    1.40	  15.6896	  1.0	   0.2569	   0.1375	  41.00	  22.00	   0.74	  10.00	   4.00
	 1200.000	    1.40	  15.6896	  1.0	   0.2569	   0.1375	  41.00	  22.00	   0.74	  10.00	   4.00
	 1500.000	    1.35	  16.0228	  1.0	   0.2838	   0.1596	  37.00	  29.00	   0.36	  10.00	   3.00
1 10000.0 8.85000