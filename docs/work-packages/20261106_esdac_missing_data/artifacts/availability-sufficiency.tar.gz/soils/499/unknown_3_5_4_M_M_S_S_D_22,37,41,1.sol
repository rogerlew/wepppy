7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:18:42.333825
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# Source warning: source.categorical.empty field=fao90lev1
# Source warning: source.profile.single_horizon field=horizons
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           24    unknownNo information
#  usedom              3     3     Arable land, cereals
#  textdepchg          5     5     No textural change between 20 and 120 cm depth
#  il                  4     4     Impermeable layer within 40 cm
#  cectop              1     M     Medium (15-40 cmol(+)/kg)
#  cecsub              1     M     Medium (15-40 cmol(+)/kg)
#  dgh                 3     S     Shallow ( < 40 cm)
#  dimp                2     S     Shallow ( < 80 cm)
#  dr                  1     D     Deep (80 - 120 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            22.0    unused
#  SAND            41.0    unused
#  SILT            37.0    unused
#  OC               0.7    unused
#  BD               1.4    unused
#  GRAVEL           4.0    unused
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1    unused
#  theta_s          0.4    unused
#  alpha            0.0    unused
#  npar             1.4    unused
#  ks              15.7    unused
#  wp               0.1    unused
#  fc               0.3    unused
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	0.254166687
#  sl2  	5  	0.254166687
#  sl3  	15  	0.254166687
#  sl4  	30  	22.037501762999998
#  sl5  	60  	5.662500453
#  sl6  	100  	5.662500453
#  sl7  	200  	5.662500453
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 2
#  ksat_last = 5.662500453
#
Any comments:
1 0
'No information'		'loam'	2	0.1500	0.7500	9835700.00	0.0230	1.9540
	  200.0	    1.40	  15.6896	  1.0	   0.2569	   0.1375	  41.00	  22.00	   0.74	  27.50	   4.00
	  400.000	    1.40	  15.6896	  1.0	   0.2569	   0.1375	  41.00	  22.00	   0.74	  27.50	   4.00
1 10000.0 0.91500