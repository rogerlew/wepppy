7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:19:02.490760
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# Source warning: source.categorical.empty field=fao90lev1
# Source warning: source.profile.single_horizon field=horizons
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           24    unknownNo information
#  usedom              1     1     Pasture, grassland, grazing land
#  textdepchg          5     5     No textural change between 20 and 120 cm depth
#  il                  2     2     Impermeable layer between 80 and 150 cm
#  cectop              1     M     Medium (15-40 cmol(+)/kg)
#  cecsub              2     L     Low ( < 15 cmol(+)/kg)
#  dgh                 3     S     Shallow ( < 40 cm)
#  dimp                1     D     Deep ( > 80 cm)
#  dr                  5     V     Very deep ( > 120 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            21.0    unused
#  SAND            39.0    unused
#  SILT            40.0    unused
#  OC               0.9    unused
#  BD               1.4    unused
#  GRAVEL           4.0    unused
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1    unused
#  theta_s          0.4    unused
#  alpha            0.0    unused
#  npar             1.4    unused
#  ks              15.7    unused
#  wp               0.1    unused
#  fc               0.3    unused
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	0.254166687
#  sl2  	5  	22.037501762999998
#  sl3  	15  	27.595835541
#  sl4  	30  	0.008333334
#  sl5  	60  	7.975000637999999
#  sl6  	100  	7.975000637999999
#  sl7  	200  	7.975000637999999
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 3
#  ksat_last = 7.975000637999999
#
Any comments:
1 0
'No information'		'loam'	2	0.1500	0.7500	10412000.00	0.0219	1.7150
	 200.0	    1.40	  15.6588	  1.0	   0.2522	   0.1344	  39.00	  21.00	   0.86	  27.50	   4.00
	 1150.000	    1.40	  15.6588	  1.0	   0.2522	   0.1344	  39.00	  21.00	   0.86	  27.50	   4.00
1 10000.0 0.03000