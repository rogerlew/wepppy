7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:19:05.327721
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# Source warning: source.categorical.empty field=fao90lev1
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           24    unknownNo information
#  usedom              1     1     Pasture, grassland, grazing land
#  textdepchg          5     5     No textural change between 20 and 120 cm depth
#  il                  1     1     No impermeable layer within 150 cm
#  cectop              2     L     Low ( < 15 cmol(+)/kg)
#  cecsub              2     L     Low ( < 15 cmol(+)/kg)
#  dgh                 2     V     Very deep ( > 120 cm)
#  dimp                1     D     Deep ( > 80 cm)
#  dr                  1     D     Deep (80 - 120 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            23.0      28.0
#  SAND            37.0      36.0
#  SILT            40.0      36.0
#  OC               1.1       0.4
#  BD               1.4       1.4
#  GRAVEL           4.0       5.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.4       0.4
#  alpha            0.0       0.0
#  npar             1.4       1.4
#  ks              15.5      15.8
#  wp               0.1       0.2
#  fc               0.3       0.3
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	0.254166687
#  sl2  	5  	0.254166687
#  sl3  	15  	0.254166687
#  sl4  	30  	0.254166687
#  sl5  	60  	8.850000708
#  sl6  	100  	8.850000708
#  sl7  	200  	8.850000708
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 3
#  ksat_last = 8.850000708
#
Any comments:
1 0
'No information'		'loam'	3	0.1500	0.7500	10412000.00	0.0194	1.8450
	 200.0	    1.38	  15.4948	  1.0	   0.2600	   0.1411	  37.00	  23.00	   1.07	  10.00	   4.00
	 1200.000	    1.38	  15.4948	  1.0	   0.2600	   0.1411	  37.00	  23.00	   1.07	  10.00	   4.00
	 1500.000	    1.35	  15.8453	  1.0	   0.2797	   0.1567	  36.00	  28.00	   0.37	  10.00	   5.00
1 10000.0 0.91500