7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:18:45.667358
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# Source warning: source.categorical.empty field=fao90lev1
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           24    unknownNo information
#  usedom              3     3     Arable land, cereals
#  textdepchg          4     4     Textural change between 80 and 120 cm depth
#  il                  2     2     Impermeable layer between 80 and 150 cm
#  cectop              2     L     Low ( < 15 cmol(+)/kg)
#  cecsub              2     L     Low ( < 15 cmol(+)/kg)
#  dgh                 3     S     Shallow ( < 40 cm)
#  dimp                2     S     Shallow ( < 80 cm)
#  dr                  3     M     Moderate (40 - 80 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY             4.0       5.0
#  SAND            86.0      85.0
#  SILT            10.0      10.0
#  OC               2.0       0.9
#  BD               1.7       1.7
#  GRAVEL           2.0       3.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.3       0.3
#  alpha            0.0       0.0
#  npar             1.9       1.9
#  ks             108.8     101.9
#  wp               0.1       0.1
#  fc               0.1       0.1
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	11.533334256
#  sl2  	5  	11.533334256
#  sl3  	15  	22.037501762999998
#  sl4  	30  	22.037501762999998
#  sl5  	60  	5.662500453
#  sl6  	100  	5.662500453
#  sl7  	200  	5.662500453
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = None
#  ksat_last = 5.662500453
#
Any comments:
1 0
'No information'		'sand loam'	3	0.1500	0.7500	4649000.00	0.0060	2.3500
	 200.0	    1.73	 108.7842	  1.0	   0.1055	   0.0513	  86.00	   4.00	   1.97	  10.00	   2.00
	 1000.000	    1.73	 108.7842	  1.0	   0.1055	   0.0513	  86.00	   4.00	   1.97	  10.00	   2.00
	 1150.000	    1.70	 101.8654	  1.0	   0.1138	   0.0538	  85.00	   5.00	   0.91	  10.00	   3.00
1 10000.0 5.66250