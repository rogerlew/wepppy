7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:19:05.766169
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# Source warning: source.categorical.empty field=fao90lev1
# Source warning: source.profile.single_horizon field=horizons
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           24    unknownNo information
#  usedom              3     3     Arable land, cereals
#  textdepchg          7     7     Textural change between 60 and 120 cm depth
#  il                  3     3     Impermeable layer between 40 and 80 cm
#  cectop              1     M     Medium (15-40 cmol(+)/kg)
#  cecsub              2     L     Low ( < 15 cmol(+)/kg)
#  dgh                 3     S     Shallow ( < 40 cm)
#  dimp                1     D     Deep ( > 80 cm)
#  dr                  4     S     Shallow ( < 40 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            19.0    unused
#  SAND            37.0    unused
#  SILT            44.0    unused
#  OC               1.0    unused
#  BD               1.4    unused
#  GRAVEL           4.0    unused
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1    unused
#  theta_s          0.4    unused
#  alpha            0.0    unused
#  npar             1.4    unused
#  ks              16.0    unused
#  wp               0.1    unused
#  fc               0.2    unused
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	11.533334256
#  sl2  	5  	11.533334256
#  sl3  	15  	22.037501762999998
#  sl4  	30  	27.595835541
#  sl5  	60  	14.200001136
#  sl6  	100  	14.200001136
#  sl7  	200  	0.162500013
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 6
#  ksat_last = 0.162500013
#
Any comments:
1 0
'No information'		'loam'	2	0.1500	0.7500	10412000.00	0.0202	1.5850
	  200.0	    1.41	  15.9934	  1.0	   0.2428	   0.1277	  37.00	  19.00	   0.99	  27.50	   4.00
	  600.000	    1.41	  15.9934	  1.0	   0.2428	   0.1277	  37.00	  19.00	   0.99	  27.50	   4.00
1 10000.0 0.58500