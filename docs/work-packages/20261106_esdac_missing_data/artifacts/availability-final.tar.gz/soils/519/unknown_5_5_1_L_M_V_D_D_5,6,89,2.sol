7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:08:10.680519
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# Source warning: source.categorical.empty field=fao90lev1
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           24    unknownNo information
#  usedom              5     5     Forest, coppice
#  textdepchg          5     5     No textural change between 20 and 120 cm depth
#  il                  1     1     No impermeable layer within 150 cm
#  cectop              2     L     Low ( < 15 cmol(+)/kg)
#  cecsub              1     M     Medium (15-40 cmol(+)/kg)
#  dgh                 2     V     Very deep ( > 120 cm)
#  dimp                1     D     Deep ( > 80 cm)
#  dr                  1     D     Deep (80 - 120 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY             5.0       5.0
#  SAND            89.0      89.0
#  SILT             6.0       6.0
#  OC               0.5       0.3
#  BD               1.7       1.7
#  GRAVEL           2.0       1.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.3       0.3
#  alpha            0.0       0.0
#  npar             2.1       2.1
#  ks             168.5     168.5
#  wp               0.1       0.1
#  fc               0.1       0.1
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS Forest
#    salb = 0.06
#    ini_sat = 0.5
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	11.533334256
#  sl2  	5  	11.533334256
#  sl3  	15  	11.533334256
#  sl4  	30  	11.533334256
#  sl5  	60  	0.233333352
#  sl6  	100  	0.233333352
#  sl7  	200  	0.233333352
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 6
#  ksat_last = 0.233333352
#
Any comments:
1 0
'No information'		'sand loam'	3	0.0600	0.5000	3880600.00	0.0192	2.6470
	 200.0	    1.70	 168.5390	  1.0	   0.0929	   0.0524	  89.00	   5.00	   0.50	  10.00	   2.00
	 1200.000	    1.70	 168.5390	  1.0	   0.0929	   0.0524	  89.00	   5.00	   0.50	  10.00	   2.00
	 1500.000	    1.70	 168.5390	  1.0	   0.0929	   0.0524	  89.00	   5.00	   0.30	  27.50	   1.00
1 10000.0 0.84000