7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:08:33.375768
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# Source warning: source.usedom.no_information field=usedom
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           14    PH    Phaeozem
#  usedom              0     0     No information
#  textdepchg          5     5     No textural change between 20 and 120 cm depth
#  il                  1     1     No impermeable layer within 150 cm
#  cectop              1     M     Medium (15-40 cmol(+)/kg)
#  cecsub              1     M     Medium (15-40 cmol(+)/kg)
#  dgh                 1     M     Moderate (40 - 80 cm)
#  dimp                1     D     Deep ( > 80 cm)
#  dr                  1     D     Deep (80 - 120 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            23.0      33.0
#  SAND            35.0      29.0
#  SILT            42.0      38.0
#  OC               1.3       0.5
#  BD               1.4       1.4
#  GRAVEL           3.0       5.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.4       0.4
#  alpha            0.0       0.0
#  npar             1.4       1.4
#  ks              15.1      11.8
#  wp               0.1       0.2
#  fc               0.3       0.3
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	11.533334256
#  sl2  	5  	11.533334256
#  sl3  	15  	22.037501762999998
#  sl4  	30  	27.595835541
#  sl5  	60  	14.200001136
#  sl6  	100  	14.200001136
#  sl7  	200  	14.200001136
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = None
#  ksat_last = 14.200001136
#
Any comments:
1 0
'Phaeozem'		'loam'	3	0.1500	0.7500	10412000.00	0.0178	1.8450
	 200.0	    1.38	  15.1065	  1.0	   0.2593	   0.1411	  35.00	  23.00	   1.26	  27.50	   3.00
	 1200.000	    1.38	  15.1065	  1.0	   0.2593	   0.1411	  35.00	  23.00	   1.26	  27.50	   3.00
	 1500.000	    1.38	  11.8415	  1.0	   0.2940	   0.1700	  29.00	  33.00	   0.50	  27.50	   5.00
1 10000.0 14.20000