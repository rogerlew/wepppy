7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:07:45.266439
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# Source warning: source.categorical.empty field=fao90lev1
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           24    unknownNo information
#  usedom              1     1     Pasture, grassland, grazing land
#  textdepchg          2     2     Textural change between 40 and 60 cm depth
#  il                  2     2     Impermeable layer between 80 and 150 cm
#  cectop              2     L     Low ( < 15 cmol(+)/kg)
#  cecsub              2     L     Low ( < 15 cmol(+)/kg)
#  dgh                 2     V     Very deep ( > 120 cm)
#  dimp                1     D     Deep ( > 80 cm)
#  dr                  3     M     Moderate (40 - 80 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            10.0      15.0
#  SAND            75.0      68.0
#  SILT            15.0      17.0
#  OC               0.7       0.3
#  BD               1.6       1.5
#  GRAVEL          10.0       9.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.4       0.4
#  alpha            0.0       0.0
#  npar             1.6       1.5
#  ks              50.3      34.6
#  wp               0.1       0.1
#  fc               0.2       0.2
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	11.533334256
#  sl2  	5  	11.533334256
#  sl3  	15  	11.533334256
#  sl4  	30  	11.533334256
#  sl5  	60  	0.233333352
#  sl6  	100  	0.233333352
#  sl7  	200  	0.233333352
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 6
#  ksat_last = 0.233333352
#
Any comments:
1 0
'No information'		'sand loam'	3	0.1500	0.7500	5609500.00	0.0171	2.4500
	  200.0	    1.58	  50.2881	  1.0	   0.1751	   0.0754	  75.00	  10.00	   0.70	  10.00	  10.00
	  500.000	    1.58	  50.2881	  1.0	   0.1751	   0.0754	  75.00	  10.00	   0.70	  10.00	  10.00
	 1150.000	    1.51	  34.6215	  1.0	   0.2143	   0.0996	  68.00	  15.00	   0.27	  10.00	   9.00
1 10000.0 0.84000