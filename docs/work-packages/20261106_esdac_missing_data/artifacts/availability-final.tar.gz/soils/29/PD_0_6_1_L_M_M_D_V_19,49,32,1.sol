7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:06:19.866024
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# Source warning: source.usedom.no_information field=usedom
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           12    PD    Podzoluvisol
#  usedom              0     0     No information
#  textdepchg          6     6     Textural change between 20 and 60 cm depth
#  il                  1     1     No impermeable layer within 150 cm
#  cectop              2     L     Low ( < 15 cmol(+)/kg)
#  cecsub              1     M     Medium (15-40 cmol(+)/kg)
#  dgh                 1     M     Moderate (40 - 80 cm)
#  dimp                1     D     Deep ( > 80 cm)
#  dr                  5     V     Very deep ( > 120 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            19.0      24.0
#  SAND            32.0      25.0
#  SILT            49.0      51.0
#  OC               2.2       0.5
#  BD               1.4       1.4
#  GRAVEL           1.0       4.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.4       0.4
#  alpha            0.0       0.0
#  npar             1.4       1.4
#  ks              16.2      12.5
#  wp               0.1       0.1
#  fc               0.2       0.3
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	11.533334256
#  sl2  	5  	11.533334256
#  sl3  	15  	11.533334256
#  sl4  	30  	11.533334256
#  sl5  	60  	0.233333352
#  sl6  	100  	0.233333352
#  sl7  	200  	0.233333352
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 6
#  ksat_last = 0.233333352
#
Any comments:
1 0
'Podzoluvisol'		'loam'	3	0.1500	0.7500	10412000.00	0.0146	1.5850
	  200.0	    1.40	  16.1896	  1.0	   0.2409	   0.1278	  32.00	  19.00	   2.22	  10.00	   1.00
	  400.000	    1.40	  16.1896	  1.0	   0.2409	   0.1278	  32.00	  19.00	   2.22	  10.00	   1.00
	 1500.000	    1.40	  12.5197	  1.0	   0.2592	   0.1437	  25.00	  24.00	   0.50	  27.50	   4.00
1 10000.0 0.84000