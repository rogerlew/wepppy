7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:07:11.606374
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           15    RG    Regosol
#  usedom              5     5     Forest, coppice
#  textdepchg          5     5     No textural change between 20 and 120 cm depth
#  il                  1     1     No impermeable layer within 150 cm
#  cectop              2     L     Low ( < 15 cmol(+)/kg)
#  cecsub              2     L     Low ( < 15 cmol(+)/kg)
#  dgh                 2     V     Very deep ( > 120 cm)
#  dimp                1     D     Deep ( > 80 cm)
#  dr                  4     S     Shallow ( < 40 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY             8.0       8.0
#  SAND            79.0      79.0
#  SILT            13.0      13.0
#  OC               2.6       1.3
#  BD               1.6       1.2
#  GRAVEL          10.0       0.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.4       0.4
#  alpha            0.0       0.0
#  npar             1.6       1.6
#  ks              64.8     204.1
#  wp               0.1       0.1
#  fc               0.2       0.2
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS Forest
#    salb = 0.06
#    ini_sat = 0.5
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	11.533334256
#  sl2  	5  	11.533334256
#  sl3  	15  	11.533334256
#  sl4  	30  	11.533334256
#  sl5  	60  	0.233333352
#  sl6  	100  	0.233333352
#  sl7  	200  	0.233333352
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 6
#  ksat_last = 0.233333352
#
Any comments:
1 0
'Regosol'		'sand loam'	3	0.0600	0.5000	5225300.00	0.0062	2.4360
	 200.0	    1.62	  64.8054	  1.0	   0.1525	   0.0654	  79.00	   8.00	   2.59	  10.00	  10.00
	 1200.000	    1.62	  64.8054	  1.0	   0.1525	   0.0654	  79.00	   8.00	   2.59	  10.00	  10.00
	 1500.000	    1.20	 204.0835	  1.0	   0.1744	   0.0781	  79.00	   8.00	   1.29	  10.00	   0.00
1 10000.0 0.84000