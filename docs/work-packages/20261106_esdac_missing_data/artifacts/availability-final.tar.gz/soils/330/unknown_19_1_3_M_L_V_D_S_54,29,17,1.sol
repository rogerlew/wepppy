7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:07:27.090139
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# Source warning: source.categorical.empty field=fao90lev1
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           24    unknownNo information
#  usedom              19    19    Extensive pasture, grazing, rough pasture
#  textdepchg          1     1     Textural change between 20 and 40 cm depth
#  il                  3     3     Impermeable layer between 40 and 80 cm
#  cectop              1     M     Medium (15-40 cmol(+)/kg)
#  cecsub              2     L     Low ( < 15 cmol(+)/kg)
#  dgh                 2     V     Very deep ( > 120 cm)
#  dimp                1     D     Deep ( > 80 cm)
#  dr                  4     S     Shallow ( < 40 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY            54.0      53.0
#  SAND            17.0      22.0
#  SILT            29.0      25.0
#  OC               4.5       1.2
#  BD               0.8       1.2
#  GRAVEL           1.0       1.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.6       0.5
#  alpha            0.0       0.0
#  npar             1.3       1.3
#  ks             136.4      25.5
#  wp               0.3       0.2
#  fc               0.4       0.4
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	11.533334256
#  sl2  	5  	11.533334256
#  sl3  	15  	11.533334256
#  sl4  	30  	11.533334256
#  sl5  	60  	0.233333352
#  sl6  	100  	0.233333352
#  sl7  	200  	0.233333352
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 6
#  ksat_last = 0.233333352
#
Any comments:
1 0
'No information'		'clay loam'	3	0.1500	0.7500	3076980.00	0.0069	3.5000
	  200.0	    0.84	 136.4375	  1.0	   0.3895	   0.2501	  17.00	  54.00	   4.54	  27.50	   1.00
	  300.000	    0.84	 136.4375	  1.0	   0.3895	   0.2501	  17.00	  54.00	   4.54	  27.50	   1.00
	  600.000	    1.23	  25.5179	  1.0	   0.3600	   0.2231	  22.00	  53.00	   1.23	  10.00	   1.00
1 10000.0 0.84000