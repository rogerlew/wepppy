7778
#
#            WEPPcloud (c) University of Idaho
#
#  Build Date: 2026-11-06 18:07:27.693898
#  Source Data: ESDAC ESDB, EU Soil Hydro Grids v1.0
#
#
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO 
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO 
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN 
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE 
# POSSIBILITY OF SUCH DAMAGE.
# 
# Source warning: source.categorical.empty field=fao90lev1
# ESDAC ESDB Soil Parameters
#
#  Attribute           PX    Abbr  Long Desc.
#  ------------------------------------------------------------------------------------------------------------------------
#  fao90lev1           24    unknownNo information
#  usedom              3     3     Arable land, cereals
#  textdepchg          4     4     Textural change between 80 and 120 cm depth
#  il                  1     1     No impermeable layer within 150 cm
#  cectop              1     M     Medium (15-40 cmol(+)/kg)
#  cecsub              2     L     Low ( < 15 cmol(+)/kg)
#  dgh                 2     V     Very deep ( > 120 cm)
#  dimp                1     D     Deep ( > 80 cm)
#  dr                  1     D     Deep (80 - 120 cm)
#
# ESDAC STU Soil Parameters
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  CLAY             3.0       4.0
#  SAND            45.0      51.0
#  SILT            52.0      45.0
#  OC               4.6       0.8
#  BD               0.8       1.7
#  GRAVEL          15.0      17.0
#
# Rosetta Soil Parameter Estimates Based on ESDAC
#
#  Attribute        Top       Sub
#  ------------------------------------------------------------------------------------------------------------------------
#  theta_r          0.1       0.1
#  theta_s          0.5       0.3
#  alpha            0.0       0.0
#  npar             1.6       1.5
#  ks             345.9      20.7
#  wp               0.1       0.1
#  fc               0.2       0.2
#  + ks, wp, and fc used for WEPP soil parameters
#
# Land IS NOT Forest
#    salb = 0.15
#    ini_sat = 0.75
#
# EU Soil Hydro Grids
#
#  Code	Depth	ksat
#  ------------------------------------------------------------------------------------------------------------------------
#  sl1  	0  	11.533334256
#  sl2  	5  	11.533334256
#  sl3  	15  	11.533334256
#  sl4  	30  	11.533334256
#  sl5  	60  	0.233333352
#  sl6  	100  	0.233333352
#  sl7  	200  	0.233333352
#
#  res_lyr_ksat_threshold = 2.0
#  res_lyr_i = 6
#  ksat_last = 0.233333352
#
Any comments:
1 0
'No information'		'silt loam'	3	0.1500	0.7500	10412000.00	0.0140	0.5450
	 200.0	    0.84	 345.9378	  1.0	   0.1886	   0.1040	  45.00	   3.00	   4.60	  27.50	  15.00
	 1000.000	    0.84	 345.9378	  1.0	   0.1886	   0.1040	  45.00	   3.00	   4.60	  27.50	  15.00
	 1500.000	    1.67	  20.6814	  1.0	   0.1826	   0.0784	  51.00	   4.00	   0.81	  10.00	  17.00
1 10000.0 0.84000