9002
# 
# WEPPcloud v.0.1.0 (c) University of Idaho
# 
# Build Date: 2026-01-18 02:37:25.829823
# Source Data: Surgo
# 
# Mukey: 3120194
# Major Component: 27433685 (comppct_r = 45.0)
# Texture: silt loam
# 
# Chkey   hzname  mask hzdepb_r  ksat_r fraggt10_r frag3to10_r dbthirdbar_r    clay    sand     vfs      om
# ------------------------------------------------------------------------------------------------------------
# 81940457   Oi     X        3.0   373.0        0.0         0.0          0.2     7.0    66.8    10.0    75.0
# 81940458   A               8.0     9.0        5.0         8.0          0.8    10.0    30.0     9.3     3.5
# 81940453   Bw1            36.0     9.0        7.0        15.0          0.9    10.0    30.0     9.3     2.0
# 81940452   Bw2            64.0    28.0        7.0        22.0          0.9    10.0    55.0    13.4     1.5
# 81940456   2EBb           77.0     9.0        5.0        17.0         1.44    14.0    30.0     9.8     2.0
# 81940455   2Bwb1         125.0     9.0        5.0        17.0         1.53    14.0    45.0    12.6     1.5
# 81940454   2Bwb2         158.0     9.0        5.0        22.0         1.53    14.0    45.0    12.6    0.75
# 
# Restricting Layer:
# ksat threshold: 2.00000
# type: -
# ksat: -
# 
# defaults applied to missing chorizon data:
# sandtotal_r  ->      66.800
# claytotal_r  ->       7.000
# om_r         ->       7.000
# cec7_r       ->      11.300
# sandvf_r     ->      10.000
# smr          ->      55.500
# 
# Build Notes:
# 81940458::wilt_pt estimated from wfifteenbar_r and rock
# 81940458::field_cap estimated from wthirdbar_r and rock
# 81940453::wilt_pt estimated from wfifteenbar_r and rock
# 81940453::field_cap estimated from wthirdbar_r and rock
# 81940452::wilt_pt estimated from wfifteenbar_r and rock
# 81940452::field_cap estimated from wthirdbar_r and rock
# 81940456::wilt_pt estimated from wfifteenbar_r and rock
# 81940456::field_cap estimated from wthirdbar_r and rock
# 81940455::wilt_pt estimated from wfifteenbar_r and rock
# 81940455::field_cap estimated from wthirdbar_r and rock
# 81940454::wilt_pt estimated from wfifteenbar_r and rock
# 81940454::field_cap estimated from wthirdbar_r and rock
# res_lyr_i None
# 
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# 
# 
# If you change the original contexts of this file please
# indicate it by putting an 'X' in the box here -> [ ]
# 
# 
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::9002.0migration
# Build Date: 2026-01-18 02:37:36.799609
# Source File: :/wc1/runs/ap/apostolic-saw/soils/3120194.sol
# 
# Replacements
# --------------------------
# luse -> forest
# stext -> silt loam
# ki -> 1000000
# kr -> 5.00E-05
# shcrit -> 1.5
# avke -> 40
# ksflag -> 0
# ksatadj -> 0
# ksatfac -> 1.5
# ksatrec -> 0.3
# pmet_kcb -> 0.95
# pmet_rawp -> 0.8
# rdmax -> 2
# xmxlai -> 14
# keffflag -> 0
# lkeff -> -9999
# 
# h0_min_depth = None
# h0_max_om = None
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::modify_initial_sat(initial_sat=0.75)
Any comments:
1 0
0	 'forest'	 'silt loam'	 1.5 	 0.3
'Harl-Limberjim-Rock outcrop complex, 60 to 90 percent north slopes'	 'GRV-ASHY-SIL'	 7	 0.23	 0.75	 1000000	 5e-05	 1.5
	80.0	 0.8	 40	 10.0	 0.266	 0.074	 30.0	 10.0	 3.5	 25.0	 66.94	 0.08159	 0.5365	 0.002992	 1.587	 314.5	 0.1304	 0.2125
	200.0	 0.9	 40	 10.0	 0.228	 0.058	 30.0	 10.0	 2.0	 11.7	 70.36	 0.07804	 0.5074	 0.003187	 1.59	 215.3	 0.1219	 0.2067
	360.0	 0.9	 32.4	 10.0	 0.228	 0.058	 30.0	 10.0	 2.0	 11.7	 70.36	 0.07804	 0.5074	 0.003187	 1.59	 215.3	 0.1219	 0.2067
	640.0	 0.9	 100.8	 1.0	 0.148	 0.054	 55.0	 10.0	 1.5	 10.5	 74.44	 0.07738	 0.5073	 0.006794	 1.49	 215.3	 0.1221	 0.23
	770.0	 1.44	 32.4	 1.0	 0.19	 0.078	 30.0	 14.0	 2.0	 13.7	 76.6	 0.07337	 0.3875	 0.005466	 1.483	 19.12	 0.1107	 0.2179
	1250.0	 1.53	 32.4	 1.0	 0.188	 0.076	 45.0	 14.0	 1.5	 12.5	 75.82	 0.0715	 0.3655	 0.009027	 1.42	 14.91	 0.109	 0.2224
	1600.0	 1.53	 32.4	 1.0	 0.126	 0.048	 45.0	 14.0	 0.75	 10.4	 83.94	 0.0715	 0.3655	 0.009027	 1.42	 14.91	 0.109	 0.2224
1 10000.0 0.01
