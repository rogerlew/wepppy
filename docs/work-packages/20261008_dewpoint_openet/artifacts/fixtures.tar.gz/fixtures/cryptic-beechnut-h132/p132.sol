9002
# 
# WEPPcloud v.0.1.0 (c) University of Idaho
# 
# Build Date: 2026-09-08 06:33:24.951410
# Source Data: Surgo
# 
# Mukey: 76684
# Major Component: 26579127 (comppct_r = 85.0)
# Texture: sand loam
# 
# Chkey   hzname  mask hzdepb_r(cm) ksat_r(um/s) fraggt10_r frag3to10_r dbthirdbar_r    clay    sand     vfs      om
# ------------------------------------------------------------------------------------------------------------
# 79316621   Oe     X        3.0   373.0        0.0         0.0          0.2    15.0    35.0     5.0    75.0
# 79316622   H1             10.0    28.0       15.0         5.0          1.2     7.5    68.5    11.9     2.0
# 79316623   H2             20.0    28.0        3.0         0.0          1.2     7.5    68.5    11.9    1.25
# 79316624   H3             89.0    28.0        3.0         0.0          1.4     7.5    68.5    11.9    0.75
# 79316625   H4            152.0    28.0        3.0         0.0          1.4     7.5    83.5    12.2    0.25
# 
# Restricting Layer:
# ksat threshold (um/s): 2.00000
# type: -
# ksat: -
# 
# defaults applied to missing chorizon data:
# sandtotal_r  ->      66.800
# claytotal_r  ->       7.000
# om_r         ->       7.000
# cec7_r       ->      11.300
# sandvf_r     ->      10.000
# smr          ->      55.500
# 
# Build Notes:
# 79316622::wilt_pt estimated from wfifteenbar_r and rock
# 79316622::field_cap estimated from wthirdbar_r and rock
# 79316623::wilt_pt estimated from wfifteenbar_r and rock
# 79316623::field_cap estimated from wthirdbar_r and rock
# 79316624::wilt_pt estimated from wfifteenbar_r and rock
# 79316624::field_cap estimated from wthirdbar_r and rock
# 79316625::wilt_pt estimated from wfifteenbar_r and rock
# 79316625::field_cap estimated from wthirdbar_r and rock
# res_lyr_i None
# 
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# 
# 
# If you change the original contexts of this file please
# indicate it by putting an 'X' in the box here -> [ ]
# 
# 
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::9002.0migration
# Build Date: 2026-09-08 06:33:52.449025
# Source File: :/wc1/runs/cr/cryptic-beechnut/soils/76684.sol
# 
# Replacements
# --------------------------
# luse -> forest
# stext -> sand loam
# ki -> 400000
# kr -> 8.00E-05
# shcrit -> 2
# avke -> 60
# bd ->
# ksflag -> 0
# ksatadj -> 0
# ksatfac -> 1.5
# ksatrec -> 0.3
# pmet_kcb -> 0.95
# pmet_rawp -> 0.8
# rdmax -> 2
# xmxlai -> 14
# keffflag -> 0
# lkeff -> -9999
# plant.data.decfct -> 1
# plant.data.dropfc -> 1
# 
# h0_min_depth = None
# h0_max_om = None
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::modify_initial_sat(initial_sat=0.75)
Any comments:
1 0
0	 'forest'	 'sand loam'	 1.5 	 0.3
'Kiper stony ashy sandy loam, 30 to 65 percent slopes'	 'ST-ASHY-SL'	 4	 0.23	 0.75	 400000	 8e-05	 2
	100.0	 1.2	 60	 10.0	 0.2029	 0.0794	 68.5	 7.5	 2.0	 12.5	 32.0	 0.06605	 0.4383	 0.01351	 1.537	 129.3	 0.08754	 0.195
	200.0	 1.2	 60	 10.0	 0.1662	 0.0593	 68.5	 7.5	 1.25	 12.5	 22.4	 0.06605	 0.4383	 0.01351	 1.537	 129.3	 0.08754	 0.195
	890.0	 1.4	 100.8	 1.0	 0.1679	 0.0608	 68.5	 7.5	 0.75	 10.0	 24.34	 0.06176	 0.393	 0.01588	 1.541	 72.68	 0.07893	 0.1834
	1600.0	 1.4	 100.8	 1.0	 0.1649	 0.0577	 83.5	 7.5	 0.25	 7.5	 27.25	 0.06167	 0.4047	 0.02259	 1.821	 195.2	 0.06454	 0.135
1 10000.0 0.01
