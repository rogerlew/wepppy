9002
# 
# WEPPcloud v.0.1.0 (c) University of Idaho
# 
# Build Date: 2026-08-07 20:23:39.507913
# Source Data: Surgo
# 
# Mukey: 469992
# Major Component: 27419521 (comppct_r = 30.0)
# Texture: sand loam
# 
# Chkey   hzname  mask hzdepb_r(cm) ksat_r(um/s) fraggt10_r frag3to10_r dbthirdbar_r    clay    sand     vfs      om
# ------------------------------------------------------------------------------------------------------------
# 81885860   A              24.0    92.0        0.0         0.0          1.6     5.0    78.5    15.2    0.75
# 81885861   C              33.0    92.0        0.0         0.0          1.6     5.0    78.5    15.2    0.75
# 81885858   Cr     X       55.0    0.03        0.0         0.0       1.5336     0.0    66.8    10.0     0.0
# 81885859   R      X       80.0    0.03        0.0         0.0       1.5336     0.0    66.8    10.0     0.0
# 
# Restricting Layer:
# ksat threshold (um/s): 2.00000
# type: -
# ksat: -
# 
# defaults applied to missing chorizon data:
# sandtotal_r  ->      66.800
# claytotal_r  ->       7.000
# om_r         ->       7.000
# cec7_r       ->      11.300
# sandvf_r     ->      10.000
# smr          ->      55.500
# 
# Build Notes:
# 81885860::wilt_pt estimated from wfifteenbar_r and rock
# 81885860::field_cap estimated from wthirdbar_r and rock
# 81885861::wilt_pt estimated from wfifteenbar_r and rock
# 81885861::field_cap estimated from wthirdbar_r and rock
# res_lyr_i None
# 
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# 
# 
# If you change the original contexts of this file please
# indicate it by putting an 'X' in the box here -> [ ]
# 
# 
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::9002.0migration
# Build Date: 2026-08-07 20:23:40.358135
# Source File: :/wc1/runs/ha/hand-to-mouth-drought/_pups/omni/scenarios/undisturbed/soils/469992.sol
# 
# Replacements
# --------------------------
# luse -> shrub
# stext -> sand loam
# ki -> 400000
# kr -> 0.0001
# shcrit -> 2
# avke -> 40
# bd ->
# ksflag -> 0
# ksatadj -> 0
# ksatfac -> 1.5
# ksatrec -> 0.3
# pmet_kcb -> 1.2
# pmet_rawp -> 0.8
# rdmax -> 0.5
# xmxlai -> 5
# keffflag -> 0
# lkeff -> -9999
# plant.data.decfct ->
# plant.data.dropfc ->
# 
# h0_min_depth = None
# h0_max_om = None
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::modify_initial_sat(initial_sat=0.75)
# wepppy.wepp.soils.utils.WeppSoilUtil::modify_kslast(kslast=0.0)
Any comments:
1 0
0	 'shrub'	 'sand loam'	 1.5 	 0.3
'Rock outcrop-Sumiwawa-Hipuk complex, 30 to 75 percent slopes'	 'GR-LS'	 3	 0.3	 0.75	 400000	 0.0001	 2
	200.0	 1.6	 40	 10.0	 0.1656	 0.0557	 78.5	 5.0	 0.75	 4.2	 39.0	 0.05393	 0.3491	 0.02352	 1.689	 80.31	 0.05912	 0.1404
	240.0	 1.6	 331.2	 10.0	 0.1656	 0.0557	 78.5	 5.0	 0.75	 4.2	 39.0	 0.05393	 0.3491	 0.02352	 1.689	 80.31	 0.05912	 0.1404
	400.0	 1.6	 331.2	 10.0	 0.1512	 0.0512	 78.5	 5.0	 0.75	 4.2	 18.0	 0.05393	 0.3491	 0.02352	 1.689	 80.31	 0.05912	 0.1404
0 0.0 0.0
