9002
# 
# WEPPcloud v.0.1.0 (c) University of Idaho
# 
# Build Date: 2026-01-18 02:37:29.684243
# Source Data: Surgo
# 
# Mukey: 3114479
# Major Component: 26607072 (comppct_r = 40.0)
# Texture: silt loam
# 
# Chkey   hzname  mask hzdepb_r  ksat_r fraggt10_r frag3to10_r dbthirdbar_r    clay    sand     vfs      om
# ------------------------------------------------------------------------------------------------------------
# 79408375   Oi     X        5.0   373.0        0.0         0.0          0.2     7.0    66.8    10.0    75.0
# 79408376   A1             35.0     9.0        0.0         0.0          1.0    21.5    26.1     8.6     3.0
# 79408377   A2             56.0     9.0        0.0         9.0          1.1    23.5    21.7     8.8     2.0
# 79408378   2Bt            96.0     9.0        0.0        33.0         1.45    26.0    38.0    11.3     1.5
# 79408374   2R            106.016.631501366310225         -           -        1.5196     7.0    66.8    10.0     7.0
# 
# Restricting Layer:
# ksat threshold: 2.00000
# type: -
# ksat: -
# 
# defaults applied to missing chorizon data:
# sandtotal_r  ->      66.800
# claytotal_r  ->       7.000
# om_r         ->       7.000
# cec7_r       ->      11.300
# sandvf_r     ->      10.000
# smr          ->      55.500
# 
# Build Notes:
# 79408376::wilt_pt estimated from wfifteenbar_r and rock
# 79408376::field_cap estimated from wthirdbar_r and rock
# 79408377::wilt_pt estimated from wfifteenbar_r and rock
# 79408377::field_cap estimated from wthirdbar_r and rock
# 79408378::wilt_pt estimated from wfifteenbar_r and rock
# 79408378::field_cap estimated from wthirdbar_r and rock
# 79408374::using default rock content of 55.5%
# 79408374::ksat_r estimated from rosetta2
# 79408374::wilt_pt estimated from rosetta2
# 79408374::field_cap estimated from rosetta2
# 79408374::bd estimated from sand, vfs, and clay
# res_lyr_i None
# 
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# 
# 
# If you change the original contexts of this file please
# indicate it by putting an 'X' in the box here -> [ ]
# 
# 
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::9002.0migration
# Build Date: 2026-01-18 02:37:33.711561
# Source File: :/wc1/runs/ap/apostolic-saw/soils/3114479.sol
# 
# Replacements
# --------------------------
# luse -> forest
# stext -> silt loam
# ki -> 1000000
# kr -> 5.00E-05
# shcrit -> 1.5
# avke -> 40
# ksflag -> 0
# ksatadj -> 0
# ksatfac -> 1.5
# ksatrec -> 0.3
# pmet_kcb -> 0.95
# pmet_rawp -> 0.8
# rdmax -> 2
# xmxlai -> 14
# keffflag -> 0
# lkeff -> -9999
# 
# h0_min_depth = None
# h0_max_om = None
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::modify_initial_sat(initial_sat=0.75)
Any comments:
1 0
0	 'forest'	 'silt loam'	 1.5 	 0.3
'Larabee-Klickson-Anatone complex, 30 to 60 percent slopes'	 'ASHY-SIL'	 5	 0.16	 0.75	 1000000	 5e-05	 1.5
	200.0	 1.0	 40	 10.0	 0.2909	 0.1227	 26.1	 21.5	 3.0	 20.0	 12.0	 0.09527	 0.5089	 0.003895	 1.491	 94.41	 0.1514	 0.2548
	350.0	 1.0	 32.4	 10.0	 0.2909	 0.1227	 26.1	 21.5	 3.0	 20.0	 12.0	 0.09527	 0.5089	 0.003895	 1.491	 94.41	 0.1514	 0.2548
	560.0	 1.1	 32.4	 1.0	 0.3552	 0.1577	 21.7	 23.5	 2.0	 19.0	 37.21	 0.09686	 0.4889	 0.003919	 1.482	 55.28	 0.1518	 0.2589
	960.0	 1.45	 32.4	 1.0	 0.344	 0.188	 38.0	 26.0	 1.5	 18.0	 59.8	 0.09591	 0.4035	 0.007753	 1.368	 10.66	 0.1493	 0.27
	1200.0	 1.52	 59.8734	 1.0	 0.188	 0.09	 66.8	 7.0	 7.0	 11.3	 55.5	 0.05875	 0.3645	 0.01673	 1.516	 46.72	 0.07638	 0.181
1 10000.0 0.01
