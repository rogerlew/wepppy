9002
# 
# WEPPcloud v.0.1.0 (c) University of Idaho
# 
# Build Date: 2026-01-18 02:37:28.628348
# Source Data: Surgo
# 
# Mukey: 64420
# Major Component: 27458239 (comppct_r = 40.0)
# Texture: loam
# 
# Chkey   hzname  mask hzdepb_r  ksat_r fraggt10_r frag3to10_r dbthirdbar_r    clay    sand     vfs      om
# ------------------------------------------------------------------------------------------------------------
# 82004025   Oi     X        5.0   373.0        0.0         0.0          0.2    15.0    35.0     5.0    75.0
# 82004028   H1             35.0     9.0        0.0         5.0          1.2    22.0    41.1    11.8     4.0
# 82004027   H2             76.0     9.0        0.0        23.0         1.33    27.5    34.7    10.3     2.0
# 82004026   H3            157.0     9.0        0.0        43.0         1.35    35.0    33.3    10.1    0.75
# 
# Restricting Layer:
# ksat threshold: 2.00000
# type: -
# ksat: -
# 
# defaults applied to missing chorizon data:
# sandtotal_r  ->      66.800
# claytotal_r  ->       7.000
# om_r         ->       7.000
# cec7_r       ->      11.300
# sandvf_r     ->      10.000
# smr          ->      55.500
# 
# Build Notes:
# 82004028::wilt_pt estimated from wfifteenbar_r and rock
# 82004028::field_cap estimated from wthirdbar_r and rock
# 82004027::wilt_pt estimated from wfifteenbar_r and rock
# 82004027::field_cap estimated from wthirdbar_r and rock
# 82004026::wilt_pt estimated from wfifteenbar_r and rock
# 82004026::field_cap estimated from wthirdbar_r and rock
# res_lyr_i None
# 
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# 
# 
# If you change the original contexts of this file please
# indicate it by putting an 'X' in the box here -> [ ]
# 
# 
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::9002.0migration
# Build Date: 2026-01-18 02:37:32.668173
# Source File: :/wc1/runs/ap/apostolic-saw/soils/64420.sol
# 
# Replacements
# --------------------------
# luse -> forest
# stext -> loam
# ki -> 400000
# kr -> 3.00E-05
# shcrit -> 1
# avke -> 50
# ksflag -> 0
# ksatadj -> 0
# ksatfac -> 1.5
# ksatrec -> 0.3
# pmet_kcb -> 0.95
# pmet_rawp -> 0.8
# rdmax -> 2
# xmxlai -> 14
# keffflag -> 0
# lkeff -> -9999
# 
# h0_min_depth = None
# h0_max_om = None
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::modify_initial_sat(initial_sat=0.75)
Any comments:
1 0
0	 'forest'	 'loam'	 1.5 	 0.3
'Umatilla-Kahler-Gwin association, 35 to 70 percent slopes'	 'L'	 4	 0.16	 0.75	 400000	 3e-05	 1
	200.0	 1.2	 50	 10.0	 0.3186	 0.1605	 41.1	 22.0	 4.0	 17.5	 12.12	 0.0925	 0.4564	 0.006803	 1.425	 38.03	 0.1435	 0.2626
	350.0	 1.2	 32.4	 10.0	 0.3186	 0.1605	 41.1	 22.0	 4.0	 17.5	 12.12	 0.0925	 0.4564	 0.006803	 1.425	 38.03	 0.1435	 0.2626
	760.0	 1.33	 32.4	 1.0	 0.3896	 0.2192	 34.7	 27.5	 2.0	 15.0	 38.4	 0.09982	 0.4358	 0.006895	 1.387	 17.16	 0.1557	 0.278
	1600.0	 1.35	 32.4	 1.0	 0.326	 0.202	 33.3	 35.0	 0.75	 17.5	 67.22	 0.1102	 0.4478	 0.008005	 1.341	 14.93	 0.1761	 0.3033
1 10000.0 0.01
