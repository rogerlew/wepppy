9002
# 
# WEPPcloud v.0.1.0 (c) University of Idaho
# 
# Build Date: 2026-09-08 06:33:25.052389
# Source Data: Surgo
# 
# Mukey: 77089
# Major Component: 26579073 (comppct_r = 85.0)
# Texture: loam
# 
# Chkey   hzname  mask hzdepb_r(cm) ksat_r(um/s) fraggt10_r frag3to10_r dbthirdbar_r    clay    sand     vfs      om
# ------------------------------------------------------------------------------------------------------------
# 79316547   Oe     X        3.0   373.0        0.0         0.0          0.2    15.0    35.0     5.0    75.0
# 79316548   H1             13.0     9.0        5.0         8.0          1.2    12.0    45.0    12.6     2.5
# 79316549   H2             36.0     9.0        3.0        25.0          1.2    12.0    45.0    12.6    0.75
# 79316550   H3             77.0     9.0        3.0        33.0         1.35    12.0    45.0    12.6    0.75
# 79316546   H4            152.0     9.0        5.0        35.0         1.35    23.0    44.8    13.2    0.25
# 
# Restricting Layer:
# ksat threshold (um/s): 2.00000
# type: -
# ksat: -
# 
# defaults applied to missing chorizon data:
# sandtotal_r  ->      66.800
# claytotal_r  ->       7.000
# om_r         ->       7.000
# cec7_r       ->      11.300
# sandvf_r     ->      10.000
# smr          ->      55.500
# 
# Build Notes:
# 79316548::wilt_pt estimated from wfifteenbar_r and rock
# 79316548::field_cap estimated from wthirdbar_r and rock
# 79316549::wilt_pt estimated from wfifteenbar_r and rock
# 79316549::field_cap estimated from wthirdbar_r and rock
# 79316550::wilt_pt estimated from wfifteenbar_r and rock
# 79316550::field_cap estimated from wthirdbar_r and rock
# 79316546::wilt_pt estimated from wfifteenbar_r and rock
# 79316546::field_cap estimated from wthirdbar_r and rock
# res_lyr_i None
# 
# THIS FILE AND THE CONTAINED DATA IS PROVIDED BY THE UNIVERSITY OF IDAHO
# 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF IDAHO
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHERE IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS FILE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# 
# 
# If you change the original contexts of this file please
# indicate it by putting an 'X' in the box here -> [ ]
# 
# 
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::9002.0migration
# Build Date: 2026-09-08 06:33:44.041368
# Source File: :/wc1/runs/cr/cryptic-beechnut/soils/77089.sol
# 
# Replacements
# --------------------------
# luse -> forest
# stext -> loam
# ki -> 400000
# kr -> 3.00E-05
# shcrit -> 1
# avke -> 50
# bd ->
# ksflag -> 0
# ksatadj -> 0
# ksatfac -> 1.5
# ksatrec -> 0.3
# pmet_kcb -> 0.95
# pmet_rawp -> 0.8
# rdmax -> 2
# xmxlai -> 14
# keffflag -> 0
# lkeff -> -9999
# plant.data.decfct -> 1
# plant.data.dropfc -> 1
# 
# h0_min_depth = None
# h0_max_om = None
# 
# wepppy.wepp.soils.utils.WeppSoilUtil::modify_initial_sat(initial_sat=0.75)
Any comments:
1 0
0	 'forest'	 'loam'	 1.5 	 0.3
'Jumpmore gravelly ashy loam, 30 to 60 percent north slopes, stony'	 'GR-ASHY-L'	 5	 0.23	 0.75	 400000	 3e-05	 1
	130.0	 1.2	 50	 10.0	 0.3248	 0.1149	 45.0	 12.0	 2.5	 15.0	 45.19	 0.07355	 0.4327	 0.006467	 1.497	 59.44	 0.1104	 0.2175
	200.0	 1.2	 50	 10.0	 0.288	 0.086	 45.0	 12.0	 0.75	 15.0	 54.64	 0.07355	 0.4327	 0.006467	 1.497	 59.44	 0.1104	 0.2175
	360.0	 1.2	 32.4	 10.0	 0.288	 0.086	 45.0	 12.0	 0.75	 15.0	 54.64	 0.07355	 0.4327	 0.006467	 1.497	 59.44	 0.1104	 0.2175
	770.0	 1.35	 32.4	 1.0	 0.234	 0.074	 45.0	 12.0	 0.75	 15.0	 66.08	 0.07071	 0.3997	 0.007527	 1.477	 33.45	 0.1052	 0.2149
	1600.0	 1.35	 32.4	 1.0	 0.206	 0.094	 44.8	 23.0	 0.25	 15.0	 77.2	 0.09191	 0.4238	 0.008455	 1.393	 20.82	 0.1414	 0.2635
1 10000.0 0.01
